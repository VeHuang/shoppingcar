var BASE_URL = 'https://pwcfrontendtest.azurewebsites.net/';
export default {
  BASE_URL: BASE_URL,
  LOGIN_URL: BASE_URL + 'login',
  ITEMS_URL: BASE_URL + 'getlist'
}