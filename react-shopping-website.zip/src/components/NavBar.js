import React, {Component} from 'react'
import * as rs from 'reactstrap'

export default class Layout extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            dropdownOpen: false
        };
    }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }

  render () {
    return (
        <rs.Container>
            <rs.Row>
                <rs.Col md={2} sm={2}>
                    <div>
                        <h1 style ={styles.logo}>
                            <a style={styles.logoText}>OlsonKart</a>
                        </h1>
                    </div>
                </rs.Col>
                <rs.Col md={6} sm={5}>
                    <div className="navi">                      
                           
                    </div>
                    <div className="navis">

                    </div>
                </rs.Col>
                <rs.Col md={4} sm={5}>
                    <div>Test</div>
                </rs.Col>
            </rs.Row>
        </rs.Container>
    );
  }
}


const styles = {
  logo: {
    fontSie: '40px',
    margin: 0,
    padding: '10px 0px'
  },
  logoText:{
    color: '#fff',
    fontFamily: "'Open Sans Condensed',sans-serif"
  }
}

// const styles = {
//   logo: {
//     marginRight: '5px',
//     width: '30px',
//     height: '30px'
//   },
//   menu: {
//     minHeight: '1080px'
//   }
// }