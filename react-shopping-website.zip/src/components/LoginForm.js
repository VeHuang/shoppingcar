import React from 'react';
import { Col, Button, Form, FormGroup, Label, Input } from 'reactstrap';

export default class LoginForm extends React.Component {
render(){
    return (
        <Form className='m-5' style={styles.form}>
            <FormGroup row>
                <Label htmlFor="email" sm={3} size="lg">Email</Label>
                <Col sm={9}>
                    <Input type="email" name="email" id="email" placeholder="Email" />
                </Col>
            </FormGroup>
            <FormGroup row> 
                <Label htmlFor="password" sm={3} size="lg">Password</Label>
                <Col sm={9}>
                    <Input type="password" name="password" id="password" placeholder="Password" />
                </Col>
            </FormGroup>
            <FormGroup row>
                <Col sm={{size: 9, offset: 3}}>
                    <Label check>
                        <Input type="checkbox" />{' '}
                        Remember me
                    </Label>
                </Col>
            </FormGroup>
            <FormGroup row> 
                <Col sm={{size: 9, offset: 3}}>
                    <Button type="submit" color="primary">Sign in</Button>
                    <Button type="reset" className="ml-3">Reset</Button>
                </Col>
            </FormGroup>
        </Form>
    );
}
} 

const styles = {
  form: {
    width: '400px'
  }
}